X=rand(100,1000);

tic
Y=mexNormalize(X);
t=toc;
