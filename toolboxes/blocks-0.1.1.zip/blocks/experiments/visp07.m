global wrd;
wrd.prefix = '/mnt/e0.2/scratch/brian/releasedata/superpixel';
vismulti('p07.*');

fprintf('\n\nIntersection / Union\n\n');
vismulti('iu', 'p07.*');

