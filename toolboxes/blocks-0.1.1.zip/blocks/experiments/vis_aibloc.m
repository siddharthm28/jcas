global wrd
wrd.prefix = 'work/aibloc';

visloc('gz.*');
