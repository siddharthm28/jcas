vis = 0;


run_quickrec
if vis
  visgraz
  visp07
  visp09
end

run_aibloc
if vis
 vis_aibloc 
end

run_aib
if vis
  vis_aib 
end

