global wrd;
wrd.prefix = '/mnt/e0.2/scratch/brian/releasedata/superpixel';
visloc('gz.*');

